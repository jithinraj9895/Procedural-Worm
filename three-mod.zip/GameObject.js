import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import * as CANNON from 'cannon-es';
import { CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';

class GameObject {
    constructor({
        scene,
        world,
        controller = false,
        modelUrl,
        position = { x: 0, y: 0, z: 0 },
        mass = 1,
        labelText = null, // 👈 add label option
    }) {
        this.scene = scene;
        this.world = world;
        this.controller = controller;
        this.modelUrl = modelUrl;
        this.position = position;
        this.mass = mass;

        this.mesh = null;
        this.body = null;
        this.mixer = null;
        this.idleAction = null;
        this.runningAction = null;
        this.activeAction = null;
        this.keys = {};
        this.direction = 0;
        this.aPressed = false;
        this.dPressed = false;

        this.collisionCallback = null;

        // Label properties
        this.label = null;
        this.labelText = labelText;

        this.loadModel();
        this.initKeyBindings();
    }

    loadModel() {
        const loader = new GLTFLoader();
        loader.load(this.modelUrl, (gltf) => {
            this.mesh = gltf.scene;
            this.mesh.position.set(this.position.x, this.position.y, this.position.z);
            this.scene.add(this.mesh);

            // Physics body
            const shape = new CANNON.Box(new CANNON.Vec3(1, 1, 1));
            this.body = new CANNON.Body({
                mass: this.mass,
                position: new CANNON.Vec3(this.position.x, this.position.y, this.position.z),
                shape: shape
            });
            this.body.fixedRotation = true;
            this.body.updateMassProperties();
            this.body.gameObject = this;

            this.body.addEventListener('collide', (event) => {
                const otherBody = event.body;
                const otherGameObject = otherBody.gameObject || null;
                if (this.collisionCallback) {
                    this.collisionCallback(otherGameObject, event);
                }
            });

            this.world.addBody(this.body);

            // Animations
            if (gltf.animations && gltf.animations.length > 0) {
                this.mixer = new THREE.AnimationMixer(this.mesh);

                const idleClip = gltf.animations.find(a => a.name.toLowerCase().includes('idle')) || gltf.animations[0];
                const runClip = gltf.animations.find(a => a.name.toLowerCase().includes('run') || a.name.toLowerCase().includes('walk'));

                this.idleAction = this.mixer.clipAction(idleClip);
                if (runClip) {
                    this.runningAction = this.mixer.clipAction(runClip);
                }

                this.activeAction = this.idleAction;
                this.activeAction.play();
            }

            // --- LABEL CREATION ---
            if (this.labelText) {
                const div = document.createElement('div');
                div.className = 'label';
                div.textContent = this.labelText;
                div.style.color = 'white';
                div.style.fontSize = '8px';
                div.style.whiteSpace = 'nowrap';

                this.label = new CSS2DObject(div);
                this.label.position.set(0, 6, 0); // above head (adjust Y as needed)
                this.mesh.add(this.label);
            }
        });
    }

    setLabelText(newText) {
        if (this.label) {
            this.label.element.textContent = newText;
        }
    }

    update(delta = 1 / 60) {
        if (this.mesh && this.body) {
            let speed = 34;
            let vx = 0, vz = 0;

            if (this.controller) {
                // Handle rotation
                if (this.keys['KeyA'] && !this.aPressed) {
                    this.direction = (this.direction + 1) % 4;
                    this.mesh.rotation.y = this.direction * Math.PI / 2;
                    this.aPressed = true;
                }
                if (!this.keys['KeyA']) this.aPressed = false;

                if (this.keys['KeyD'] && !this.dPressed) {
                    this.direction = (this.direction + 3) % 4;
                    this.mesh.rotation.y = this.direction * Math.PI / 2;
                    this.dPressed = true;
                }
                if (!this.keys['KeyD']) this.dPressed = false;

                // Movement
                if (this.keys['KeyS']) {
                    switch (this.direction) {
                        case 0: vz -= speed; break;
                        case 1: vx -= speed; break;
                        case 2: vz += speed; break;
                        case 3: vx += speed; break;
                    }
                }
                if (this.keys['KeyW']) {
                    switch (this.direction) {
                        case 0: vz += speed; break;
                        case 1: vx += speed; break;
                        case 2: vz -= speed; break;
                        case 3: vx -= speed; break;
                    }
                }

                this.body.velocity.x = vx;
                this.body.velocity.z = vz;
            }

            // sync mesh position with physics
            this.mesh.position.copy(this.body.position);

            // Animations
            const isMoving = vx !== 0 || vz !== 0;
            if (this.mixer) {
                if (isMoving && this.runningAction && this.activeAction !== this.runningAction) {
                    this.activeAction.fadeOut(0.2);
                    this.runningAction.reset().fadeIn(0.2).play();
                    this.activeAction = this.runningAction;
                } else if (!isMoving && this.idleAction && this.activeAction !== this.idleAction) {
                    this.activeAction.fadeOut(0.2);
                    this.idleAction.reset().fadeIn(0.2).play();
                    this.activeAction = this.idleAction;
                }
                this.mixer.update(delta);
            }
        }
    }

    // --------- COLLISION HANDLING ---------
    setOnCollide(callback) {
        this.collisionCallback = callback;
    }

    checkCollisionWith(other, threshold = 2) {
        if (!this.mesh || !other.mesh) return false;
        const pos1 = this.mesh.position;
        const pos2 = other.mesh.position;
        const dx = pos1.x - pos2.x;
        const dz = pos1.z - pos2.z;
        const dist = Math.sqrt(dx * dx + dz * dz);
        return dist < threshold;
    }

    initKeyBindings() {
        window.addEventListener('keydown', (event) => {
            this.keys[event.code] = true;
        });

        window.addEventListener('keyup', (event) => {
            this.keys[event.code] = false;
        });
    }
}

export default GameObject;
