import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import * as CANNON from 'cannon-es';
import GameObject from './GameObject.js';
import { OrbitControls } from 'three/examples/jsm/Addons.js';
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import { Label } from './Label.js';

// Scene setup

let npc = [];

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 2, 5);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Orbit Controls
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1, 0);
controls.update();

// Lighting
const light = new THREE.DirectionalLight(0xffffff, 1);
light.position.set(5, 10, 7.5);
scene.add(light);

// Cannon.js world setup
const world = new CANNON.World({
    gravity: new CANNON.Vec3(0, -9.82, 0)
});

// Ground plane
const groundBody = new CANNON.Body({
    mass: 0,
    shape: new CANNON.Plane(),
});
groundBody.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
world.addBody(groundBody);

const groundGeometry = new THREE.PlaneGeometry(20, 20);
const groundMaterial = new THREE.MeshStandardMaterial({ color: 0x808080 });
const groundMesh = new THREE.Mesh(groundGeometry, groundMaterial);
groundMesh.rotation.x = -Math.PI / 2;
scene.add(groundMesh);

// Setup CSS2DRenderer once
const labelRenderer = new CSS2DRenderer();
labelRenderer.setSize(window.innerWidth, window.innerHeight);
labelRenderer.domElement.style.position = "absolute";
labelRenderer.domElement.style.top = "0px";
document.body.appendChild(labelRenderer.domElement);

// GameObject instance
const gameObject = new GameObject({
    scene,
    world,
    controller: true,
    modelUrl: 'models/RobotExpressive.glb', // Replace with your actual model path
    position: { x: 0, y: 20, z: 0 },
    mass: 1,
    labelText: "Player 1" // Add label text
});

// GameObject instance
const ai = new GameObject({
    scene,
    world,
    controller: false,
    modelUrl: 'models/RobotExpressive.glb', // Replace with your actual model path
    position: { x: 0, y: 20, z: 0 },
    mass: 1,
    labelText: "Player 2" // Add label text

});

// Update label dynamically
setTimeout(() => {
    ai.setLabelText("Running!");
}, 4000);


gameObject.setOnCollide((other, event) => {
    if (other) {
        console.log('Player collided with:', other.modelUrl);
    } else {
        console.log('Player collided with something (maybe ground)');
    }
});


// Animation loop
function animate() {
    world.step(1 / 60);
    gameObject.update();
    ai.update();

    if (gameObject.checkCollisionWith(ai, 3)) {
        console.log("Distance check: robot is near stranger");
    }

    renderer.render(scene, camera);
    labelRenderer.render(scene, camera);
    requestAnimationFrame(animate);
}

animate();