import { CSS2DRenderer } from "three/examples/jsm/renderers/CSS2DRenderer.js";

export class Label {
    static renderer = null; // shared renderer
    static camera = null;
    static scene = null;

    constructor({ text = "Label", color = "white", fontSize = "16px" }, gameObject) {
        this.gameObject = gameObject;

        // Init renderer once
        if (!Label.renderer) {
            Label.renderer = new CSS2DRenderer();
            Label.renderer.setSize(window.innerWidth, window.innerHeight);
            Label.renderer.domElement.style.position = "absolute";
            Label.renderer.domElement.style.top = "0px";
            document.body.appendChild(Label.renderer.domElement);

            // Resize handler
            window.addEventListener("resize", () => {
                Label.renderer.setSize(window.innerWidth, window.innerHeight);
            });
        }

        // Create DOM element
        this.div = document.createElement("div");
        this.div.className = "label";
        this.div.textContent = text;
        this.div.style.position = "absolute";
        this.div.style.color = color;
        this.div.style.fontSize = fontSize;
        this.div.style.whiteSpace = "nowrap";
        document.body.appendChild(this.div);
    }

    // Update label position (must be called every frame)
    update() {
        if (!Label.camera) return;

        const vector = this.gameObject.position.clone();
        vector.project(Label.camera); // project world -> screen

        const x = (vector.x * 0.5 + 0.5) * window.innerWidth;
        const y = (-vector.y * 0.5 + 0.5) * window.innerHeight;

        this.div.style.left = `${x}px`;
        this.div.style.top = `${y - 20}px`; // offset above
    }

    // Static setup (call once)
    static setup(scene, camera) {
        Label.scene = scene;
        Label.camera = camera;
    }

    // Static render call
    static render() {
        if (Label.renderer && Label.scene && Label.camera) {
            Label.renderer.render(Label.scene, Label.camera);
        }
    }

    // Update text dynamically
    setText(newText) {
        this.div.textContent = newText;
    }

    // Update style dynamically
    setStyle({ color, fontSize }) {
        if (color) this.div.style.color = color;
        if (fontSize) this.div.style.fontSize = fontSize;
    }
}
